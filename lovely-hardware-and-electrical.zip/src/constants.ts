/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PaintBucket, Zap, Droplets, Hammer, Home, Star, Truck, ShieldCheck, HelpCircle, Phone, MapPin, Clock } from 'lucide-react';

export const BUSINESS_INFO = {
  name: "Lovely Hardware And Electrical",
  address: "Hatai Kheda Rd, near Post Office, Anandnagar, Bhopal, Madhya Pradesh 462022, India",
  phone: "099773 43032",
  phoneRaw: "+919977343032",
  hours: "Open daily, 9 AM - 9 PM",
  whatsapp: "919977343032",
  googleMapsUrl: "https://www.google.com/maps/place/Lovely+Hardware+And+Electrical/@23.2540297,77.4881362,3411m/data=!3m1!1e3!4m15!1m8!3m7!1s0x397c41e40648af0d:0xb256191a4c992275!2sAnandnagar,+Bhopal,+Madhya+Pradesh+462022!3b1!8m2!3d23.2520103!4d77.4856647!16s%2Fg%2F1jkyjgkld!3m5!1s0x397c41e412f9ecc9:0x9a297ccbb2b101a0!8m2!3d23.2540297!4d77.4881362!16s%2Fg%2F1q64k_5bz?entry=ttu&g_ep=EgoyMDI2MDQyOS4wIKXMDSoASAFQAw%3D%3D",
  rating: 4.9,
};

export const SERVICES = [
  {
    title: "Paints",
    description: "Authorized dealer for Asian Paints and other premium brands. Thousands of shades to choose from.",
    icon: PaintBucket,
    color: "bg-blue-50 text-blue-600",
  },
  {
    title: "Electrical Items",
    description: "Wide range of wires, switches, lighting, and industrial electrical components.",
    icon: Zap,
    color: "bg-amber-50 text-amber-600",
  },
  {
    title: "Sanitary Products",
    description: "Premium bath fittings, pipes, tanks, and modern plumbing solutions.",
    icon: Droplets,
    color: "bg-cyan-50 text-cyan-600",
  },
  {
    title: "Hardware Tools",
    description: "Professional tools for every job – from DIY projects to large scale construction.",
    icon: Hammer,
    color: "bg-slate-50 text-slate-600",
  },
  {
    title: "Construction Advice",
    description: "Expert suggestions for your new home construction and renovation projects.",
    icon: Home,
    color: "bg-emerald-50 text-emerald-600",
  },
];

export const WHY_CHOOSE_US = [
  {
    title: "4.9 Star Rating",
    description: "Consistently rated as one of the best hardware stores in Bhopal.",
    icon: Star,
  },
  {
    title: "Trusted Locally",
    description: "Over a decade of service to the Anandnagar community.",
    icon: ShieldCheck,
  },
  {
    title: "Expert Guidance",
    description: "Personalized advice for paint selection and electrical planning.",
    icon: HelpCircle,
  },
  {
    title: "Fast Delivery",
    description: "Local delivery available for heavy items and bulk orders.",
    icon: Truck,
  },
];

export const REVIEWS = [
  {
    name: "Virat Rathore",
    text: "The best place in Bhopal for Asian Paints. Their suggestions for my new house were incredibly helpful and saved me a lot of money.",
    stars: 5,
  },
  {
    name: "Moen Khan",
    text: "Excellent service and genuine electrical products. The owner is very knowledgeable and always suggests the right quality items.",
    stars: 5,
  },
  {
    name: "Prateek Soni",
    text: "Fully satisfied with the sanitary fittings I bought from here. Prices are competitive and the collection is modern.",
    stars: 5,
  },
];

export const GALLERY_ITEMS = [
  {
    url: "https://images.unsplash.com/photo-1581244277943-fe4a9c777189?q=80&w=2000&auto=format&fit=crop",
    title: "Asian Paints Dealer",
  },
  {
    url: "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?q=80&w=2060&auto=format&fit=crop",
    title: "Hardware Tools",
  },
  {
    url: "https://images.unsplash.com/photo-1621905251918-48416bd8575a?q=80&w=2069&auto=format&fit=crop",
    title: "Electrical Control",
  },
  {
    url: "https://images.unsplash.com/photo-1585338107529-13afc5f02586?q=80&w=1974&auto=format&fit=crop",
    title: "Hardware Supplies",
  },
  {
    url: "https://images.unsplash.com/photo-1589939705384-5185137a7f0f?q=80&w=2070&auto=format&fit=crop",
    title: "Paint Mixing",
  },
  {
    url: "https://images.unsplash.com/photo-1572981779307-38b8cabb2407?q=80&w=1932&auto=format&fit=crop",
    title: "Premium Hardware",
  },
];
