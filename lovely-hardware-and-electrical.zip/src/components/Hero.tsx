/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ArrowRight, Phone, MapPin } from 'lucide-react';
import { motion } from 'motion/react';
import { BUSINESS_INFO } from '../constants';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-slate-900">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1513467535987-fd81bc7d62f8?q=80&w=2000&auto=format&fit=crop" 
          alt="Hardware Store background"
          className="w-full h-full object-cover opacity-30 scale-105 animate-pulse-slow"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/80 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block px-4 py-1.5 mb-6 text-xs font-bold tracking-widest text-blue-400 uppercase bg-blue-500/10 border border-blue-500/20 rounded-full">
              Leading Hardware & Paint Dealer in Bhopal
            </span>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold font-display text-white leading-[1.1] mb-6">
              Your Trusted <span className="text-blue-500">Hardware & Electrical</span> Partner
            </h1>
            <p className="text-lg md:text-xl text-slate-300 mb-10 leading-relaxed max-w-2xl">
              From premium Asian Paints to industrial electrical supplies, we provide quality products, expert advice, and reliable service – all in one place.
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <a 
              href={`tel:${BUSINESS_INFO.phoneRaw}`}
              className="group flex items-center justify-center gap-3 bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-xl font-bold transition-all transform hover:scale-105 shadow-xl shadow-blue-900/40"
            >
              <Phone className="w-5 h-5" />
              Call Now
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a 
              href={BUSINESS_INFO.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm border border-white/20 px-8 py-4 rounded-xl font-bold transition-all"
            >
              <MapPin className="w-5 h-5" />
              Get Directions
            </a>
          </motion.div>

          {/* Social Proof Stats */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mt-16 flex flex-wrap items-center gap-6 md:gap-12 border-t border-white/10 pt-8"
          >
            <div className="min-w-[120px]">
              <div className="text-2xl md:text-3xl font-bold text-white font-display">4.9/5</div>
              <div className="text-[10px] md:text-xs text-slate-400 uppercase tracking-widest font-semibold">Rating</div>
            </div>
            <div className="hidden sm:block w-px h-10 bg-white/10"></div>
            <div className="min-w-[120px]">
              <div className="text-2xl md:text-3xl font-bold text-white font-display">10+</div>
              <div className="text-[10px] md:text-xs text-slate-400 uppercase tracking-widest font-semibold">Years</div>
            </div>
            <div className="hidden sm:block w-px h-10 bg-white/10"></div>
            <div className="min-w-[120px]">
              <div className="text-2xl md:text-3xl font-bold text-white font-display">5K+</div>
              <div className="text-[10px] md:text-xs text-slate-400 uppercase tracking-widest font-semibold">Items</div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Decorative element */}
      <div className="absolute right-0 bottom-0 top-0 overflow-hidden hidden xl:block z-0 opacity-20 pointer-events-none">
         <div className="h-[200%] w-[500px] bg-blue-600/30 blur-[120px] -rotate-45 translate-x-1/2"></div>
      </div>
    </section>
  );
}
