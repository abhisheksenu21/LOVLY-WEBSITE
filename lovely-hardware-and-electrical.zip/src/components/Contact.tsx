/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { Phone, MapPin, Clock, Send, MessageCircle } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';
import { useState, FormEvent } from 'react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    requirement: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      setFormData({ name: '', phone: '', requirement: '' });
      setTimeout(() => setIsSuccess(false), 5000);
    }, 1500);
  };

  return (
    <section id="contact" className="py-24 bg-white relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-blue-50 rounded-full blur-[100px] opacity-70"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          
          {/* Contact Info */}
          <div>
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-sm font-bold tracking-widest text-blue-600 uppercase mb-3">Get in Touch</h2>
              <h2 className="text-3xl md:text-5xl font-bold font-display text-slate-900 mb-8 leading-tight">
                Visit Our Store or Send an Inquiry
              </h2>
              
              <div className="space-y-8 mt-12">
                <div className="flex gap-6 items-start">
                  <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 flex-shrink-0">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 mb-1">Our Location</h4>
                    <p className="text-slate-600 leading-relaxed max-w-xs">
                      {BUSINESS_INFO.address}
                    </p>
                    <a 
                      href={BUSINESS_INFO.googleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-block mt-3 text-sm font-bold text-blue-600 hover:underline"
                    >
                      Open in Google Maps
                    </a>
                  </div>
                </div>

                <div className="flex gap-6 items-start">
                  <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 flex-shrink-0">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 mb-1">Call Us</h4>
                    <a 
                      href={`tel:${BUSINESS_INFO.phoneRaw}`} 
                      className="text-xl font-bold text-blue-600 hover:text-blue-700 transition-colors"
                    >
                      {BUSINESS_INFO.phone}
                    </a>
                    <p className="text-sm text-slate-500 mt-1">Available for quick queries</p>
                  </div>
                </div>

                <div className="flex gap-6 items-start">
                  <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 flex-shrink-0">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 mb-1">Business Hours</h4>
                    <p className="text-slate-600">{BUSINESS_INFO.hours}</p>
                    <p className="text-sm text-slate-500 mt-1">We are open all 7 days</p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-4 mt-12">
                <a 
                  href={`https://wa.me/${BUSINESS_INFO.whatsapp}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-emerald-600/20 transition-all"
                >
                  <MessageCircle className="w-5 h-5" />
                  WhatsApp
                </a>
                <a 
                  href={BUSINESS_INFO.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-blue-600/20 transition-all"
                >
                  <MapPin className="w-5 h-5" />
                  Directions
                </a>
              </div>
            </motion.div>
          </div>

          {/* Inquiry Form */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-white border border-slate-100 p-8 md:p-12 rounded-[40px] shadow-2xl relative"
          >
            <h3 className="text-2xl font-bold text-slate-900 mb-2 font-display">Quick Inquiry</h3>
            <p className="text-slate-500 mb-8">Fill the form below and we'll get back to you shortly.</p>
            
            {isSuccess ? (
              <motion.div 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }}
                className="bg-emerald-50 border border-emerald-100 p-8 rounded-3xl text-center"
              >
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Send className="w-8 h-8" />
                </div>
                <h4 className="text-xl font-bold text-emerald-900 mb-2">Message Sent!</h4>
                <p className="text-emerald-700">Thank you for reaching out. We will contact you soon.</p>
                <button 
                  onClick={() => setIsSuccess(false)}
                  className="mt-6 text-sm font-bold text-emerald-600 hover:underline"
                >
                  Send another inquiry
                </button>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">Full Name</label>
                  <input 
                    type="text" 
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Enter your name"
                    className="w-full px-5 py-4 bg-slate-50 border-transparent border focus:border-blue-500 focus:bg-white transition-all outline-none rounded-2xl text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">Phone Number</label>
                  <input 
                    type="tel" 
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    placeholder="Enter your mobile number"
                    className="w-full px-5 py-4 bg-slate-50 border-transparent border focus:border-blue-500 focus:bg-white transition-all outline-none rounded-2xl text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">Requirement</label>
                  <textarea 
                    required
                    rows={4}
                    value={formData.requirement}
                    onChange={(e) => setFormData({...formData, requirement: e.target.value})}
                    placeholder="What are you looking for? (e.g. Paint estimates, Electrical items)"
                    className="w-full px-5 py-4 bg-slate-50 border-transparent border focus:border-blue-500 focus:bg-white transition-all outline-none rounded-2xl text-slate-900 resize-none"
                  ></textarea>
                </div>
                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white py-5 rounded-2xl font-bold font-display text-lg shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center gap-3 active:scale-[0.98]"
                >
                  {isSubmitting ? (
                    <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    <>
                      Send Inquiry
                      <Send className="w-5 h-5" />
                    </>
                  )}
                </button>
              </form>
            )}
          </motion.div>
        </div>

        {/* Embedded Map */}
        <div className="mt-24 rounded-[40px] overflow-hidden shadow-2xl h-[450px] border border-slate-100 relative group">
          <iframe 
            src="https://www.google.com/maps?q=Lovely+Hardware+And+Electrical+Bhopal&output=embed" 
            className="w-full h-full border-0 grayscale hover:grayscale-0 transition-all duration-1000"
            allowFullScreen 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>
      </div>
    </section>
  );
}
