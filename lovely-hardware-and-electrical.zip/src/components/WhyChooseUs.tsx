/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { WHY_CHOOSE_US } from '../constants';

export default function WhyChooseUs() {
  return (
    <section className="py-24 bg-slate-50 overflow-hidden relative">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-96 h-96 bg-blue-100 rounded-full blur-[100px] opacity-50"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <div className="lg:w-1/2">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-sm font-bold tracking-widest text-blue-600 uppercase mb-3">Why Work With Us</h2>
              <h2 className="text-3xl md:text-5xl font-bold font-display text-slate-900 mb-8 leading-tight">
                Quality You Can Trust, Service You'll Love
              </h2>
              <p className="text-lg text-slate-600 mb-10 leading-relaxed">
                We're more than just a hardware store. We are your partners in building your dream home. Our experts provide tailored suggestions that save you time and money.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {WHY_CHOOSE_US.map((item, index) => (
                  <div key={item.title} className="flex gap-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-white rounded-xl shadow-sm border border-slate-100 flex items-center justify-center text-blue-600">
                      <item.icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 mb-1">{item.title}</h3>
                      <p className="text-sm text-slate-500">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
          
          <div className="lg:w-1/2 w-full">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, rotate: 2 }}
              whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl relative z-10 bg-slate-200">
                <img 
                  src="https://images.unsplash.com/photo-1589939705384-5185137a7f0f?q=80&w=2070&auto=format&fit=crop" 
                  alt="Quality service" 
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Floating badges */}
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl z-20 hidden sm:block border border-slate-50">
                <div className="text-3xl font-bold text-blue-600 font-display">100%</div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">Genuine Products</div>
              </div>
              <div className="absolute top-10 -right-6 bg-blue-600 text-white p-6 rounded-2xl shadow-xl z-20 hidden sm:block">
                <div className="text-3xl font-bold font-display">Best</div>
                <div className="text-xs font-bold text-blue-100 uppercase tracking-widest text-center">Bhopal Dealer</div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
