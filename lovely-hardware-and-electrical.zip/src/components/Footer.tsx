/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BUSINESS_INFO } from '../constants';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-950 text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 border-b border-white/10 pb-16">
          <div className="lg:col-span-2">
            <a href="#home" className="flex flex-col mb-6">
              <span className="text-4xl font-cursive italic leading-none text-gold drop-shadow-sm mb-1">
                Lovely
              </span>
              <span className="text-sm tracking-[0.2em] font-semibold text-blue-500">
                HARDWARE & ELECTRICAL
              </span>
            </a>
            <p className="text-slate-400 text-lg leading-relaxed max-w-md">
              The premier destination for hardware, electrical, and paint supplies in Bhopal. Providing quality products and expert advice since 2012.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 font-display">Quick Links</h4>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#home" className="hover:text-blue-500 transition-colors">Home</a></li>
              <li><a href="#services" className="hover:text-blue-500 transition-colors">Services</a></li>
              <li><a href="#gallery" className="hover:text-blue-500 transition-colors">Gallery</a></li>
              <li><a href="#reviews" className="hover:text-blue-500 transition-colors">Reviews</a></li>
              <li><a href="#contact" className="hover:text-blue-500 transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 font-display">Visit Us</h4>
            <address className="not-italic text-slate-400 leading-relaxed mb-4">
              {BUSINESS_INFO.address}
            </address>
            <div className="text-blue-500 font-bold mb-2">{BUSINESS_INFO.phone}</div>
            <div className="text-slate-500 text-sm">{BUSINESS_INFO.hours}</div>
          </div>
        </div>

        <div className="pt-8 flex flex-col md:flex-row justify-between items-center text-slate-500 text-sm">
          <p>© {currentYear} {BUSINESS_INFO.name}. All rights reserved.</p>
          <p className="mt-2 md:mt-0">Designed for Excellence in Bhopal</p>
        </div>
      </div>
    </footer>
  );
}
